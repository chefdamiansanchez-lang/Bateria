package com.datco.saludbateria

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build

data class BatteryInfo(
    val percent: Int,
    val charging: Boolean,
    val full: Boolean,
    val healthLabel: String,
    val healthPercent: Int?,
    val tempC: Float,
    val voltageV: Float,
    val technology: String,
    val cycles: Int?,
    val chargeTimeMs: Long
)

object BatteryReader {
    fun read(ctx: Context, i: Intent): BatteryInfo {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0

        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val full = status == BatteryManager.BATTERY_STATUS_FULL

        val healthLabel = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Buena"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Sobrecalentada"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dañada"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobrevoltaje"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Con fallas"
            BatteryManager.BATTERY_HEALTH_COLD -> "Fría"
            else -> "Desconocida"
        }

        var healthPercent: Int? = null
        var cycles: Int? = null
        if (Build.VERSION.SDK_INT >= 34) {
            val h = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATE_OF_HEALTH)
            if (h in 1..100) healthPercent = h
            val c = i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)
            if (c > 0) cycles = c
        }

        val chargeMs = if (Build.VERSION.SDK_INT >= 28) bm.computeChargeTimeRemaining() else -1L

        return BatteryInfo(
            percent = pct,
            charging = charging,
            full = full,
            healthLabel = healthLabel,
            healthPercent = healthPercent,
            tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f,
            voltageV = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f,
            technology = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "—",
            cycles = cycles,
            chargeTimeMs = chargeMs
        )
    }
}
